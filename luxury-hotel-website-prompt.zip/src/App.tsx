import { useState, useEffect } from 'react';
import { MessageCircle } from 'lucide-react';
import { loadData, saveData, type HotelData } from './store';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import RoomsSection from './components/RoomsSection';
import FacilitiesSection from './components/FacilitiesSection';
import GallerySection from './components/GallerySection';
import TestimonialsSection from './components/TestimonialsSection';
import BookingSection from './components/BookingSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import AdminDashboard from './components/AdminDashboard';

export default function App() {
  const [data, setData] = useState<HotelData>(loadData());
  const [showAdmin, setShowAdmin] = useState(false);

  useEffect(() => {
    setData(loadData());
  }, []);

  const handleAdminSave = (newData: HotelData) => {
    saveData(newData);
    setData(newData);
  };

  return (
    <div className="min-h-screen bg-dark text-gray-200">
      <Navbar
        onAdminTrigger={() => setShowAdmin(true)}
        phone={data.phone}
        address={data.address}
      />

      <main>
        <HeroSection
          hotelName={data.hotelName}
          tagline={data.tagline}
          heroSubtext={data.heroSubtext}
        />

        <AboutSection
          aboutText={data.aboutText}
          aboutText2={data.aboutText2}
        />

        <RoomsSection rooms={data.rooms} />

        <FacilitiesSection data={data} />

        <GallerySection images={data.galleryImages} />

        <TestimonialsSection />

        <BookingSection
          rooms={data.rooms}
          whatsapp={data.whatsapp}
          phone={data.phone}
        />

        <ContactSection data={data} />
      </main>

      <Footer data={data} />

      {/* WhatsApp floating button */}
      <a
        href={`https://wa.me/${data.whatsapp}`}
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-float"
        title="Chat on WhatsApp"
      >
        <MessageCircle size={28} className="text-white" />
      </a>

      {/* Admin Dashboard */}
      <AdminDashboard
        show={showAdmin}
        onClose={() => setShowAdmin(false)}
        data={data}
        onSave={handleAdminSave}
      />
    </div>
  );
}
