// Types and localStorage management for Amanda Garden Hotel

export interface RoomType {
  id: string;
  name: string;
  price: string;
  description: string;
  images: string[];
}

export interface LaundryItem {
  name: string;
  price: string;
}

export interface AccountDetail {
  bankName: string;
  accountName: string;
  accountNumber: string;
}

export interface HotelData {
  hotelName: string;
  tagline: string;
  heroSubtext: string;
  aboutText: string;
  aboutText2: string;
  address: string;
  phone: string;
  whatsapp: string;
  email: string;
  rooms: RoomType[];
  laundry: LaundryItem[];
  accounts: AccountDetail[];
  poolImages: string[];
  restaurantImages: string[];
  restaurantText: string;
  eventHallImages: string[];
  eventHallText: string;
  receptionImages: string[];
  receptionText: string;
  galleryImages: string[];
  poolText: string;
}

export const defaultData: HotelData = {
  hotelName: "Amanda Garden Hotel",
  tagline: "Luxury • Comfort • Hospitality",
  heroSubtext: "Experience elegance and relaxation like never before. Your comfort is our top priority. Nestled in the heart of Akwanga, we offer world-class hospitality with a touch of home.",
  aboutText: "Welcome to Amanda Garden Hotel, a premier luxury destination located in the serene city of Akwanga, Nasarawa State. Our hotel combines modern elegance with traditional Nigerian hospitality to create an unforgettable experience for every guest. Whether you're here for business or leisure, our dedicated staff ensures your stay is nothing short of exceptional.",
  aboutText2: "With beautifully appointed rooms, a stunning garden setting, top-notch restaurant, refreshing swimming pool, and versatile event facilities, Amanda Garden Hotel is your perfect home away from home. We pride ourselves on attention to detail, premium comfort, and personalized service that keeps our guests coming back.",
  address: "3 Millennium, Opposite Model Hospital, Akwanga 960101, Nasarawa",
  phone: "0803 590 0685",
  whatsapp: "08035900685",
  email: "amandagardenhotel@gmail.com",
  rooms: [
    {
      id: "back",
      name: "Back Room",
      price: "₦10,000",
      description: "Cozy and affordable rooms perfect for budget-conscious travelers. Features basic amenities including comfortable bed, AC, and en-suite bathroom.",
      images: []
    },
    {
      id: "standard",
      name: "Standard Room",
      price: "₦12,000",
      description: "Comfortable and well-furnished rooms with modern amenities. Enjoy a restful night with quality bedding, air conditioning, flat-screen TV, and complimentary WiFi.",
      images: []
    },
    {
      id: "executive",
      name: "Executive Room",
      price: "₦15,000",
      description: "Spacious and elegantly designed rooms for the discerning guest. Features premium furnishings, workspace, mini-fridge, and luxurious bathroom amenities.",
      images: []
    },
    {
      id: "double",
      name: "Double Room",
      price: "₦20,000",
      description: "Our premium double rooms offer generous space and luxury. Perfect for couples or guests who desire extra comfort with king-size beds and premium decor.",
      images: []
    },
    {
      id: "hall",
      name: "Event Hall",
      price: "₦70,000",
      description: "Elegant and spacious event hall perfect for weddings, conferences, parties, and corporate events. Modern sound system and flexible seating arrangements.",
      images: []
    },
    {
      id: "garden",
      name: "Garden Space",
      price: "Negotiable",
      description: "Beautiful outdoor garden venue ideal for outdoor events, receptions, and celebrations. Lush greenery and scenic atmosphere create the perfect ambiance.",
      images: []
    }
  ],
  laundry: [
    { name: "T-Shirt", price: "₦500" },
    { name: "Trouser", price: "₦500" },
    { name: "Agbada", price: "₦1,000" },
    { name: "Native", price: "₦1,000" },
    { name: "Suit", price: "₦1,000" }
  ],
  accounts: [
    { bankName: "Moniepoint", accountName: "Amanda Garden Hotel", accountNumber: "5708366422" },
    { bankName: "UBA", accountName: "Amanda Garden Hotel", accountNumber: "1025770659" }
  ],
  poolImages: [],
  poolText: "Take a refreshing dip in our pristine swimming pool. Whether you're looking to swim laps or simply lounge by the poolside, our pool area offers the perfect escape from the hustle and bustle.",
  restaurantImages: [],
  restaurantText: "Savor exquisite local and continental dishes prepared by our talented chefs. Our restaurant offers a diverse menu featuring fresh ingredients and authentic flavors in an elegant dining atmosphere.",
  eventHallImages: [],
  eventHallText: "Host your special occasions in our magnificent event hall. From weddings to corporate conferences, our versatile space accommodates events of all sizes with modern amenities and professional service.",
  receptionImages: [],
  receptionText: "Our warm and welcoming reception area sets the tone for your stay. Our friendly front desk staff is available 24/7 to assist you with check-in, information, and any special requests.",
  galleryImages: []
};

const STORAGE_KEY = "amanda_garden_hotel_data";

export function loadData(): HotelData {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...defaultData, ...parsed };
    }
  } catch (e) {
    console.error("Error loading data:", e);
  }
  return { ...defaultData };
}

export function saveData(data: HotelData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error("Error saving data:", e);
  }
}

export function compressImage(file: File, maxWidth = 800, quality = 0.7): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Could not get canvas context"));
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
