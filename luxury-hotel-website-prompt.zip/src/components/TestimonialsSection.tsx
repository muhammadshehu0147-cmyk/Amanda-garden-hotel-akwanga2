import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'John D.',
    text: 'Amanda Garden Hotel is simply amazing! The environment is clean, serene and the staff are very professional. I felt right at home from the moment I checked in.',
    rating: 5,
  },
  {
    name: 'Mary S.',
    text: 'The best hotel in Akwanga! I enjoyed every moment of my stay. The rooms are comfortable, the food is excellent, and the garden is beautiful. Highly recommended.',
    rating: 5,
  },
  {
    name: 'Ahmed B.',
    text: 'Luxury, comfort and great service. Amanda Garden Hotel is my number one choice whenever I visit Akwanga. The event hall is also perfect for occasions.',
    rating: 5,
  },
  {
    name: 'Grace O.',
    text: 'I hosted my birthday party at Amanda Garden Hotel and it was absolutely fantastic! The staff went above and beyond to make sure everything was perfect.',
    rating: 5,
  },
  {
    name: 'Emeka C.',
    text: 'Clean rooms, friendly staff, and great value for money. The swimming pool is a bonus! I will definitely be coming back on my next trip.',
    rating: 5,
  },
];

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const prev = () => setCurrent((current - 1 + testimonials.length) % testimonials.length);
  const next = () => setCurrent((current + 1) % testimonials.length);

  // Get 3 visible testimonials for desktop
  const getVisible = () => {
    const items = [];
    for (let i = 0; i < 3; i++) {
      items.push(testimonials[(current + i) % testimonials.length]);
    }
    return items;
  };

  return (
    <section className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">Testimonials</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            What Our <span className="gold-text">Guests Say</span>
          </h2>
          <div className="section-divider-lg" />
        </div>

        <div className="relative">
          {/* Navigation arrows */}
          <button onClick={prev} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 z-10 w-10 h-10 rounded-full bg-dark-card border border-dark-border flex items-center justify-center text-gold hover:bg-gold hover:text-dark transition-all hidden md:flex">
            <ChevronLeft size={18} />
          </button>
          <button onClick={next} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 z-10 w-10 h-10 rounded-full bg-dark-card border border-dark-border flex items-center justify-center text-gold hover:bg-gold hover:text-dark transition-all hidden md:flex">
            <ChevronRight size={18} />
          </button>

          {/* Cards */}
          <div className="grid md:grid-cols-3 gap-6 px-4 md:px-8">
            {getVisible().map((t, i) => (
              <div key={`${t.name}-${i}`} className="bg-dark-card border border-dark-border rounded-2xl p-6 relative hover:border-gold/20 transition-all">
                <Quote className="text-gold/20 absolute top-4 left-4" size={32} />
                <Quote className="text-gold/20 absolute bottom-4 right-4 rotate-180" size={32} />
                <div className="relative z-10">
                  <div className="flex gap-1 mb-4">
                    {[...Array(t.rating)].map((_, idx) => (
                      <span key={idx} className="text-gold text-sm">★</span>
                    ))}
                  </div>
                  <p className="text-gray-300 text-sm leading-relaxed mb-6 italic font-cormorant text-lg">
                    "{t.text}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold font-bold text-sm">
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">— {t.name}</p>
                      <p className="text-gray-500 text-xs">Verified Guest</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${i === current ? 'bg-gold w-6' : 'bg-dark-border hover:bg-gold/50'}`}
              />
            ))}
          </div>

          {/* Mobile nav */}
          <div className="flex justify-center gap-4 mt-4 md:hidden">
            <button onClick={prev} className="w-10 h-10 rounded-full bg-dark-card border border-dark-border flex items-center justify-center text-gold">
              <ChevronLeft size={18} />
            </button>
            <button onClick={next} className="w-10 h-10 rounded-full bg-dark-card border border-dark-border flex items-center justify-center text-gold">
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
