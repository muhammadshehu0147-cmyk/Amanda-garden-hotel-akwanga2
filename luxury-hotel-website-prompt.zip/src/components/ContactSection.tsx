import { MapPin, Phone, Mail, MessageCircle, Send, CreditCard } from 'lucide-react';
import { useState } from 'react';
import type { HotelData } from '../store';

interface ContactProps {
  data: HotelData;
}

export default function ContactSection({ data }: ContactProps) {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
    setForm({ name: '', email: '', phone: '', message: '' });
  };

  return (
    <section id="contact" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">Get In Touch</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            Contact <span className="gold-text">Us</span>
          </h2>
          <div className="section-divider-lg" />
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Contact Info */}
          <div className="space-y-6">
            <div className="bg-dark-card border border-dark-border rounded-2xl p-8 space-y-6">
              <h3 className="font-playfair text-xl font-bold gold-text mb-4">Reach Out To Us</h3>
              
              <a href={`https://maps.google.com/?q=${encodeURIComponent(data.address)}`} target="_blank" rel="noopener noreferrer" className="flex items-start gap-4 group hover:text-gold transition-colors">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0 group-hover:bg-gold/20 transition-colors">
                  <MapPin className="text-gold" size={20} />
                </div>
                <div>
                  <p className="text-gold text-xs uppercase tracking-wider mb-1 font-medium">Address</p>
                  <p className="text-gray-300 text-sm">{data.address}</p>
                </div>
              </a>

              <a href={`tel:${data.phone.replace(/\s/g, '')}`} className="flex items-start gap-4 group hover:text-gold transition-colors">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0 group-hover:bg-gold/20 transition-colors">
                  <Phone className="text-gold" size={20} />
                </div>
                <div>
                  <p className="text-gold text-xs uppercase tracking-wider mb-1 font-medium">Phone</p>
                  <p className="text-gray-300 text-sm">{data.phone}</p>
                </div>
              </a>

              <a href={`https://wa.me/${data.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-start gap-4 group hover:text-gold transition-colors">
                <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center shrink-0 group-hover:bg-green-500/20 transition-colors">
                  <MessageCircle className="text-green-400" size={20} />
                </div>
                <div>
                  <p className="text-green-400 text-xs uppercase tracking-wider mb-1 font-medium">WhatsApp</p>
                  <p className="text-gray-300 text-sm">Chat with us on WhatsApp</p>
                </div>
              </a>

              <a href={`mailto:${data.email}`} className="flex items-start gap-4 group hover:text-gold transition-colors">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0 group-hover:bg-gold/20 transition-colors">
                  <Mail className="text-gold" size={20} />
                </div>
                <div>
                  <p className="text-gold text-xs uppercase tracking-wider mb-1 font-medium">Email</p>
                  <p className="text-gray-300 text-sm">{data.email}</p>
                </div>
              </a>
            </div>

            {/* Payment Info */}
            <div className="bg-dark-card border border-dark-border rounded-2xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <CreditCard className="text-gold" size={20} />
                <h3 className="font-playfair text-lg font-bold gold-text">Payment / Account Details</h3>
              </div>
              <div className="space-y-4">
                {data.accounts.map((acc, i) => (
                  <div key={i} className="bg-dark-surface border border-dark-border rounded-xl p-4 hover:border-gold/30 transition-colors">
                    <p className="text-gold text-xs uppercase tracking-wider mb-1 font-medium">{acc.bankName}</p>
                    <p className="text-white font-semibold">{acc.accountName}</p>
                    <p className="text-gray-400 text-sm font-mono mt-1">{acc.accountNumber}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Form + Map */}
          <div className="space-y-6">
            <div className="bg-dark-card border border-dark-border rounded-2xl p-8">
              <h3 className="font-playfair text-xl font-bold gold-text mb-6">Send Us a Message</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
                <input
                  type="tel"
                  placeholder="Your Phone Number"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
                <textarea
                  placeholder="Your Message"
                  required
                  rows={4}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full input-luxury rounded-lg resize-none"
                />
                <button type="submit" className="btn-gold rounded-lg w-full flex items-center justify-center gap-2">
                  {sent ? '✓ Message Sent!' : (
                    <>Send Message <Send size={14} /></>
                  )}
                </button>
              </form>
            </div>

            {/* Google Map */}
            <div className="rounded-2xl overflow-hidden border border-dark-border h-64">
              <iframe
                title="Amanda Garden Hotel Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.0!2d8.37!3d8.91!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zOMKwNTQnMzYuMCJOIDjCsDIyJzEyLjAiRQ!5e0!3m2!1sen!2sng!4v1"
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) brightness(0.8) contrast(1.2)' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
