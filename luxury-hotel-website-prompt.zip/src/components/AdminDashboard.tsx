import { useState, useRef } from 'react';
import { X, Upload, Trash2, Save, Lock, Eye, EyeOff, Image, Settings, BedDouble, Waves, UtensilsCrossed, PartyPopper, Building2, Camera, FileText, LogOut } from 'lucide-react';
import type { HotelData, RoomType } from '../store';
import { compressImage } from '../store';

interface AdminProps {
  show: boolean;
  onClose: () => void;
  data: HotelData;
  onSave: (data: HotelData) => void;
}

const ADMIN_PASSWORD = 'Amanda11';

type TabKey = 'general' | 'rooms' | 'pool' | 'restaurant' | 'eventHall' | 'reception' | 'gallery' | 'laundry';

export default function AdminDashboard({ show, onClose, data, onSave }: AdminProps) {
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<TabKey>('general');
  const [localData, setLocalData] = useState<HotelData>(data);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadTarget, setUploadTarget] = useState<{ section: string; roomId?: string }>({ section: '' });

  if (!show) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setAuthenticated(true);
      setError('');
      setLocalData({ ...data });
    } else {
      setError('Incorrect password. Please try again.');
    }
  };

  const handleLogout = () => {
    setAuthenticated(false);
    setPassword('');
    onClose();
  };

  const handleSave = () => {
    setSaving(true);
    onSave(localData);
    setTimeout(() => setSaving(false), 1000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: string[] = [];
    for (let i = 0; i < files.length; i++) {
      try {
        const compressed = await compressImage(files[i]);
        newImages.push(compressed);
      } catch (err) {
        console.error('Error compressing image:', err);
      }
    }

    const updated = { ...localData };
    if (uploadTarget.roomId) {
      updated.rooms = updated.rooms.map(r =>
        r.id === uploadTarget.roomId ? { ...r, images: [...r.images, ...newImages] } : r
      );
    } else {
      switch (uploadTarget.section) {
        case 'pool': updated.poolImages = [...updated.poolImages, ...newImages]; break;
        case 'restaurant': updated.restaurantImages = [...updated.restaurantImages, ...newImages]; break;
        case 'eventHall': updated.eventHallImages = [...updated.eventHallImages, ...newImages]; break;
        case 'reception': updated.receptionImages = [...updated.receptionImages, ...newImages]; break;
        case 'gallery': updated.galleryImages = [...updated.galleryImages, ...newImages]; break;
      }
    }
    setLocalData(updated);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const triggerUpload = (section: string, roomId?: string) => {
    setUploadTarget({ section, roomId });
    setTimeout(() => fileInputRef.current?.click(), 100);
  };

  const removeImage = (section: string, index: number, roomId?: string) => {
    const updated = { ...localData };
    if (roomId) {
      updated.rooms = updated.rooms.map(r =>
        r.id === roomId ? { ...r, images: r.images.filter((_, i) => i !== index) } : r
      );
    } else {
      switch (section) {
        case 'pool': updated.poolImages = updated.poolImages.filter((_, i) => i !== index); break;
        case 'restaurant': updated.restaurantImages = updated.restaurantImages.filter((_, i) => i !== index); break;
        case 'eventHall': updated.eventHallImages = updated.eventHallImages.filter((_, i) => i !== index); break;
        case 'reception': updated.receptionImages = updated.receptionImages.filter((_, i) => i !== index); break;
        case 'gallery': updated.galleryImages = updated.galleryImages.filter((_, i) => i !== index); break;
      }
    }
    setLocalData(updated);
  };

  const updateRoom = (id: string, field: keyof RoomType, value: string) => {
    setLocalData({
      ...localData,
      rooms: localData.rooms.map(r => r.id === id ? { ...r, [field]: value } : r)
    });
  };

  const tabs: { key: TabKey; label: string; icon: React.ReactNode }[] = [
    { key: 'general', label: 'General', icon: <Settings size={16} /> },
    { key: 'rooms', label: 'Rooms', icon: <BedDouble size={16} /> },
    { key: 'pool', label: 'Pool', icon: <Waves size={16} /> },
    { key: 'restaurant', label: 'Restaurant', icon: <UtensilsCrossed size={16} /> },
    { key: 'eventHall', label: 'Event Hall', icon: <PartyPopper size={16} /> },
    { key: 'reception', label: 'Reception', icon: <Building2 size={16} /> },
    { key: 'gallery', label: 'Gallery', icon: <Camera size={16} /> },
    { key: 'laundry', label: 'Laundry', icon: <FileText size={16} /> },
  ];

  const ImageGrid = ({ images, section, roomId }: { images: string[]; section: string; roomId?: string }) => (
    <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mt-4">
      {images.map((img, i) => (
        <div key={i} className="relative group rounded-lg overflow-hidden aspect-square ring-1 ring-dark-border">
          <img src={img} alt="" className="w-full h-full object-cover" />
          {/* Always-visible delete button */}
          <button
            onClick={() => {
              if (confirm('Delete this image?')) removeImage(section, i, roomId);
            }}
            className="absolute top-1 right-1 w-7 h-7 bg-red-600 hover:bg-red-500 rounded-full flex items-center justify-center shadow-lg transition-colors z-10"
            title="Delete image"
          >
            <Trash2 size={13} className="text-white" />
          </button>
        </div>
      ))}
      <button
        onClick={() => triggerUpload(section, roomId)}
        className="aspect-square rounded-lg border-2 border-dashed border-dark-border hover:border-gold/50 flex flex-col items-center justify-center gap-1 transition-colors"
      >
        <Upload size={20} className="text-gold/50" />
        <span className="text-[10px] text-gray-500">Upload</span>
      </button>
    </div>
  );

  // Login screen
  if (!authenticated) {
    return (
      <div className="fixed inset-0 z-[200] admin-overlay flex items-center justify-center p-4" onClick={onClose}>
        <div className="bg-dark-card border border-gold/20 rounded-2xl p-8 w-full max-w-sm animate-scale-in" onClick={e => e.stopPropagation()}>
          <div className="text-center mb-8">
            <div className="w-16 h-16 mx-auto rounded-full bg-gold/10 flex items-center justify-center mb-4 border border-gold/30">
              <Lock className="text-gold" size={28} />
            </div>
            <h2 className="font-playfair text-2xl font-bold gold-text">Admin Access</h2>
            <p className="text-gray-500 text-xs mt-2">Enter password to access dashboard</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => { setPassword(e.target.value); setError(''); }}
                placeholder="Enter password"
                className="w-full input-luxury rounded-lg pr-10"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gold"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {error && <p className="text-red-400 text-xs">{error}</p>}
            <button type="submit" className="btn-gold rounded-lg w-full">Login</button>
          </form>

          <button onClick={onClose} className="mt-4 text-gray-500 text-xs w-full text-center hover:text-gold">Cancel</button>
        </div>
      </div>
    );
  }

  // Dashboard
  return (
    <div className="fixed inset-0 z-[200] admin-overlay flex items-stretch">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Sidebar */}
      <div className="w-56 bg-dark-card border-r border-dark-border shrink-0 flex flex-col overflow-y-auto hidden md:flex">
        <div className="p-4 border-b border-dark-border">
          <h3 className="font-playfair text-lg font-bold gold-text">Admin Panel</h3>
          <p className="text-gray-500 text-[10px]">Amanda Garden Hotel</p>
        </div>
        <nav className="flex-1 p-2 space-y-1">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                activeTab === tab.key ? 'bg-gold/10 text-gold border border-gold/20' : 'text-gray-400 hover:text-white hover:bg-dark-surface'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-dark-border space-y-2">
          <button onClick={handleSave} className="btn-gold rounded-lg w-full text-xs py-2 flex items-center justify-center gap-2">
            <Save size={14} />
            {saving ? 'Saved!' : 'Save All'}
          </button>
          <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 text-gray-500 hover:text-red-400 text-xs py-2 transition-colors">
            <LogOut size={14} />
            Logout
          </button>
        </div>
      </div>

      {/* Mobile tabs */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-dark-card border-t border-dark-border z-10 flex overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-shrink-0 flex flex-col items-center gap-1 px-3 py-2 text-[10px] ${
              activeTab === tab.key ? 'text-gold' : 'text-gray-500'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-20 md:pb-8">
        {/* Mobile header */}
        <div className="md:hidden flex items-center justify-between mb-6">
          <h3 className="font-playfair text-lg font-bold gold-text">Admin Panel</h3>
          <div className="flex gap-2">
            <button onClick={handleSave} className="btn-gold rounded-lg text-xs px-3 py-1.5">
              {saving ? '✓' : 'Save'}
            </button>
            <button onClick={handleLogout} className="text-gray-500 hover:text-red-400">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Close button desktop */}
        <button onClick={onClose} className="hidden md:flex absolute top-4 right-4 text-gray-500 hover:text-gold transition-colors">
          <X size={24} />
        </button>

        {/* Tab content */}
        {activeTab === 'general' && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="font-playfair text-2xl font-bold text-white">General Settings</h2>
            
            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Hotel Name</label>
              <input
                value={localData.hotelName}
                onChange={(e) => setLocalData({ ...localData, hotelName: e.target.value })}
                className="w-full input-luxury rounded-lg"
              />
            </div>

            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Tagline</label>
              <input
                value={localData.tagline}
                onChange={(e) => setLocalData({ ...localData, tagline: e.target.value })}
                className="w-full input-luxury rounded-lg"
              />
            </div>

            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Hero Subtitle</label>
              <textarea
                value={localData.heroSubtext}
                onChange={(e) => setLocalData({ ...localData, heroSubtext: e.target.value })}
                rows={3}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>

            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">About Us (Paragraph 1)</label>
              <textarea
                value={localData.aboutText}
                onChange={(e) => setLocalData({ ...localData, aboutText: e.target.value })}
                rows={4}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>

            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">About Us (Paragraph 2)</label>
              <textarea
                value={localData.aboutText2}
                onChange={(e) => setLocalData({ ...localData, aboutText2: e.target.value })}
                rows={4}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Address</label>
                <input
                  value={localData.address}
                  onChange={(e) => setLocalData({ ...localData, address: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
              </div>
              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Phone</label>
                <input
                  value={localData.phone}
                  onChange={(e) => setLocalData({ ...localData, phone: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
              </div>
              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">WhatsApp Number</label>
                <input
                  value={localData.whatsapp}
                  onChange={(e) => setLocalData({ ...localData, whatsapp: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
              </div>
              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Email</label>
                <input
                  value={localData.email}
                  onChange={(e) => setLocalData({ ...localData, email: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                />
              </div>
            </div>

            <div>
              <h3 className="font-playfair text-lg font-bold text-white mb-4">Account Details</h3>
              {localData.accounts.map((acc, i) => (
                <div key={i} className="bg-dark-surface rounded-lg p-4 mb-3 space-y-2 border border-dark-border">
                  <input
                    value={acc.bankName}
                    onChange={(e) => {
                      const accs = [...localData.accounts];
                      accs[i] = { ...accs[i], bankName: e.target.value };
                      setLocalData({ ...localData, accounts: accs });
                    }}
                    placeholder="Bank Name"
                    className="w-full input-luxury rounded-lg text-sm"
                  />
                  <input
                    value={acc.accountNumber}
                    onChange={(e) => {
                      const accs = [...localData.accounts];
                      accs[i] = { ...accs[i], accountNumber: e.target.value };
                      setLocalData({ ...localData, accounts: accs });
                    }}
                    placeholder="Account Number"
                    className="w-full input-luxury rounded-lg text-sm"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'rooms' && (
          <div className="space-y-6 max-w-3xl">
            <h2 className="font-playfair text-2xl font-bold text-white">Room Management</h2>
            {localData.rooms.map((room) => (
              <div key={room.id} className="bg-dark-surface border border-dark-border rounded-xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-playfair text-lg font-bold gold-text">{room.name}</h3>
                  <span className="text-gold text-sm font-bold">{room.price}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-gray-500 text-xs mb-1 block">Room Name</label>
                    <input
                      value={room.name}
                      onChange={(e) => updateRoom(room.id, 'name', e.target.value)}
                      className="w-full input-luxury rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-gray-500 text-xs mb-1 block">Price</label>
                    <input
                      value={room.price}
                      onChange={(e) => updateRoom(room.id, 'price', e.target.value)}
                      className="w-full input-luxury rounded-lg text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-gray-500 text-xs mb-1 block">Description</label>
                  <textarea
                    value={room.description}
                    onChange={(e) => updateRoom(room.id, 'description', e.target.value)}
                    rows={2}
                    className="w-full input-luxury rounded-lg text-sm resize-none"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-gray-500 text-xs flex items-center gap-1">
                      <Image size={12} /> Room Images ({room.images.length})
                    </label>
                  </div>
                  <ImageGrid images={room.images} section="rooms" roomId={room.id} />
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'pool' && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="font-playfair text-2xl font-bold text-white">Swimming Pool</h2>
            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Description</label>
              <textarea
                value={localData.poolText}
                onChange={(e) => setLocalData({ ...localData, poolText: e.target.value })}
                rows={3}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>
            <div>
              <label className="text-gray-500 text-xs flex items-center gap-1 mb-1">
                <Image size={12} /> Pool Images ({localData.poolImages.length})
              </label>
              <ImageGrid images={localData.poolImages} section="pool" />
            </div>
          </div>
        )}

        {activeTab === 'restaurant' && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="font-playfair text-2xl font-bold text-white">Restaurant</h2>
            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Description</label>
              <textarea
                value={localData.restaurantText}
                onChange={(e) => setLocalData({ ...localData, restaurantText: e.target.value })}
                rows={3}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>
            <div>
              <label className="text-gray-500 text-xs flex items-center gap-1 mb-1">
                <Image size={12} /> Restaurant Images ({localData.restaurantImages.length})
              </label>
              <ImageGrid images={localData.restaurantImages} section="restaurant" />
            </div>
          </div>
        )}

        {activeTab === 'eventHall' && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="font-playfair text-2xl font-bold text-white">Event Hall</h2>
            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Description</label>
              <textarea
                value={localData.eventHallText}
                onChange={(e) => setLocalData({ ...localData, eventHallText: e.target.value })}
                rows={3}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>
            <div>
              <label className="text-gray-500 text-xs flex items-center gap-1 mb-1">
                <Image size={12} /> Event Hall Images ({localData.eventHallImages.length})
              </label>
              <ImageGrid images={localData.eventHallImages} section="eventHall" />
            </div>
          </div>
        )}

        {activeTab === 'reception' && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="font-playfair text-2xl font-bold text-white">Reception</h2>
            <div>
              <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Description</label>
              <textarea
                value={localData.receptionText}
                onChange={(e) => setLocalData({ ...localData, receptionText: e.target.value })}
                rows={3}
                className="w-full input-luxury rounded-lg resize-none"
              />
            </div>
            <div>
              <label className="text-gray-500 text-xs flex items-center gap-1 mb-1">
                <Image size={12} /> Reception Images ({localData.receptionImages.length})
              </label>
              <ImageGrid images={localData.receptionImages} section="reception" />
            </div>
          </div>
        )}

        {activeTab === 'gallery' && (
          <div className="space-y-6 max-w-3xl">
            <h2 className="font-playfair text-2xl font-bold text-white">General Gallery</h2>
            <p className="text-gray-400 text-sm">Upload images for the main gallery section.</p>
            <ImageGrid images={localData.galleryImages} section="gallery" />
          </div>
        )}

        {activeTab === 'laundry' && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="font-playfair text-2xl font-bold text-white">Laundry Prices</h2>
            {localData.laundry.map((item, i) => (
              <div key={i} className="flex gap-3 items-center">
                <input
                  value={item.name}
                  onChange={(e) => {
                    const laundry = [...localData.laundry];
                    laundry[i] = { ...laundry[i], name: e.target.value };
                    setLocalData({ ...localData, laundry });
                  }}
                  className="flex-1 input-luxury rounded-lg text-sm"
                  placeholder="Item name"
                />
                <input
                  value={item.price}
                  onChange={(e) => {
                    const laundry = [...localData.laundry];
                    laundry[i] = { ...laundry[i], price: e.target.value };
                    setLocalData({ ...localData, laundry });
                  }}
                  className="w-32 input-luxury rounded-lg text-sm"
                  placeholder="Price"
                />
                <button
                  onClick={() => {
                    const laundry = localData.laundry.filter((_, idx) => idx !== i);
                    setLocalData({ ...localData, laundry });
                  }}
                  className="text-red-400 hover:text-red-300 p-2"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
            <button
              onClick={() => setLocalData({ ...localData, laundry: [...localData.laundry, { name: '', price: '' }] })}
              className="btn-gold-outline rounded-lg text-xs px-4 py-2"
            >
              + Add Item
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
