import { Waves, UtensilsCrossed, PartyPopper, Building2, Wifi, Car, ImageIcon } from 'lucide-react';
import type { HotelData } from '../store';

interface FacilitiesProps {
  data: HotelData;
}

interface FacilityCardProps {
  title: string;
  text: string;
  images: string[];
  icon: React.ReactNode;
  gradient: string;
  emoji: string;
}

function FacilityCard({ title, text, images, icon, gradient, emoji }: FacilityCardProps) {
  return (
    <div className="luxury-card bg-dark-card border border-dark-border rounded-2xl overflow-hidden group hover:border-gold/30">
      {/* Image gallery */}
      <div className="relative aspect-video overflow-hidden">
        {images.length > 0 ? (
          <div className="flex w-full h-full">
            <img src={images[0]} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
          </div>
        ) : (
          <div className={`w-full h-full ${gradient} flex items-center justify-center`}>
            <div className="text-center space-y-2">
              <span className="text-5xl block">{emoji}</span>
              <div className="flex items-center gap-1 justify-center text-gray-500">
                <ImageIcon size={12} />
                <p className="text-[10px]">Upload via admin</p>
              </div>
            </div>
          </div>
        )}
        {images.length > 1 && (
          <div className="absolute bottom-2 right-2 bg-dark/80 text-gold text-xs px-2 py-1 rounded-lg">
            +{images.length - 1} more
          </div>
        )}
      </div>

      <div className="p-6">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold">
            {icon}
          </div>
          <h3 className="font-playfair text-lg font-bold text-white">{title}</h3>
        </div>
        <p className="text-gray-400 text-sm leading-relaxed">{text}</p>
      </div>
    </div>
  );
}

export default function FacilitiesSection({ data }: FacilitiesProps) {
  const facilities = [
    {
      title: 'Swimming Pool',
      text: data.poolText,
      images: data.poolImages,
      icon: <Waves size={20} />,
      gradient: 'bg-gradient-to-br from-[#0a3d62] via-[#1e5f74] to-[#0a3d62]',
      emoji: '🏊'
    },
    {
      title: 'Restaurant & Bar',
      text: data.restaurantText,
      images: data.restaurantImages,
      icon: <UtensilsCrossed size={20} />,
      gradient: 'bg-gradient-to-br from-[#2d1b00] via-[#5a3a1a] to-[#2d1b00]',
      emoji: '🍽️'
    },
    {
      title: 'Event Hall',
      text: data.eventHallText,
      images: data.eventHallImages,
      icon: <PartyPopper size={20} />,
      gradient: 'bg-gradient-to-br from-[#1a0a2e] via-[#2d1854] to-[#1a0a2e]',
      emoji: '🎉'
    },
    {
      title: 'Reception',
      text: data.receptionText,
      images: data.receptionImages,
      icon: <Building2 size={20} />,
      gradient: 'bg-gradient-to-br from-[#1a1a1a] via-[#2a2520] to-[#1a1a1a]',
      emoji: '🏨'
    },
  ];

  const quickFacilities = [
    { icon: <Waves size={18} />, name: 'Swimming Pool' },
    { icon: <UtensilsCrossed size={18} />, name: 'Restaurant' },
    { icon: <PartyPopper size={18} />, name: 'Event Hall' },
    { icon: <Building2 size={18} />, name: 'Reception' },
    { icon: <Wifi size={18} />, name: 'Free WiFi' },
    { icon: <Car size={18} />, name: 'Parking' },
  ];

  return (
    <section id="facilities" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">What We Offer</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            Our <span className="gold-text">Facilities</span>
          </h2>
          <div className="section-divider-lg mb-6" />
        </div>

        {/* Quick facilities icons bar */}
        <div className="flex flex-wrap justify-center gap-6 md:gap-10 mb-16 py-6 border-y border-dark-border">
          {quickFacilities.map((f) => (
            <div key={f.name} className="flex items-center gap-2 text-gray-400 hover:text-gold transition-colors cursor-default">
              <span className="text-gold/60">{f.icon}</span>
              <span className="text-xs font-medium uppercase tracking-wider">{f.name}</span>
            </div>
          ))}
        </div>

        {/* Facility cards grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {facilities.map((f) => (
            <FacilityCard key={f.title} {...f} />
          ))}
        </div>

        {/* Laundry section */}
        <div className="mt-16 bg-dark-card border border-dark-border rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="font-playfair text-2xl font-bold gold-text mb-2">Laundry Service</h3>
            <div className="section-divider" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {data.laundry.map((item) => (
              <div key={item.name} className="text-center p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-gold/30 transition-colors">
                <p className="text-white font-medium text-sm mb-1">{item.name}</p>
                <p className="text-gold font-bold">{item.price}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
