import { MapPin, Phone, MessageCircle, ArrowUp } from 'lucide-react';
import type { HotelData } from '../store';

interface FooterProps {
  data: HotelData;
}

export default function Footer({ data }: FooterProps) {
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <footer className="bg-dark-card border-t border-dark-border relative">
      {/* CTA Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 -mt-16">
        <div className="bg-gradient-to-r from-gold-dark via-gold to-gold-dark rounded-2xl p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl shadow-gold/10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-dark/20 flex items-center justify-center shrink-0">
              <span className="text-2xl font-playfair font-bold text-dark">AG</span>
            </div>
            <div>
              <h3 className="font-playfair text-xl md:text-2xl font-bold text-dark">Ready to Experience Luxury?</h3>
              <p className="text-dark/70 text-sm">Book your stay with us today and enjoy premium comfort.</p>
            </div>
          </div>
          <button
            onClick={() => scrollTo('booking')}
            className="bg-dark text-gold font-semibold px-8 py-3 rounded-lg text-sm uppercase tracking-wider hover:bg-dark-surface transition-colors flex items-center gap-2 shrink-0"
          >
            Book Now →
          </button>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 mt-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center text-dark font-bold font-playfair text-lg">
                AG
              </div>
              <div>
                <h4 className="font-playfair text-lg font-bold gold-text">Amanda Garden</h4>
                <p className="text-[10px] tracking-[3px] text-gold/50 uppercase">Hotel</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Luxury meets comfort at Amanda Garden Hotel. We offer you a memorable stay with world-class hospitality in the heart of Akwanga.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-playfair text-sm font-bold text-white uppercase tracking-wider mb-6">Quick Links</h4>
            <div className="space-y-3">
              {['hero|Home', 'about|About Us', 'rooms|Rooms', 'facilities|Facilities', 'gallery|Gallery', 'contact|Contact'].map(link => {
                const [id, label] = link.split('|');
                return (
                  <button
                    key={id}
                    onClick={() => scrollTo(id)}
                    className="block text-gray-400 text-sm hover:text-gold transition-colors hover:translate-x-1 transform duration-200"
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Facilities */}
          <div>
            <h4 className="font-playfair text-sm font-bold text-white uppercase tracking-wider mb-6">Facilities</h4>
            <div className="space-y-3">
              {['Swimming Pool', 'Restaurant', 'Event Hall', 'Reception', 'Free WiFi', 'Parking Space', 'Laundry Service'].map(item => (
                <p key={item} className="text-gray-400 text-sm">{item}</p>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-playfair text-sm font-bold text-white uppercase tracking-wider mb-6">Contact Us</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin size={16} className="text-gold shrink-0 mt-0.5" />
                <p className="text-gray-400 text-sm">{data.address}</p>
              </div>
              <a href={`tel:${data.phone.replace(/\s/g, '')}`} className="flex items-center gap-3 text-gray-400 text-sm hover:text-gold transition-colors">
                <Phone size={16} className="text-gold shrink-0" />
                {data.phone}
              </a>
              <a href={`https://wa.me/${data.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-gray-400 text-sm hover:text-green-400 transition-colors">
                <MessageCircle size={16} className="text-green-400 shrink-0" />
                WhatsApp Us
              </a>
            </div>

            {/* Social */}
            <div className="flex gap-3 mt-6">
              <a href="#" className="w-10 h-10 rounded-lg bg-dark-surface border border-dark-border flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/30 transition-all">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </a>
              <a href="#" className="w-10 h-10 rounded-lg bg-dark-surface border border-dark-border flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/30 transition-all">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
              </a>
              <a href={`https://wa.me/${data.whatsapp}`} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-dark-surface border border-dark-border flex items-center justify-center text-gray-400 hover:text-green-400 hover:border-green-400/30 transition-all">
                <MessageCircle size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-dark-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-xs">
            © {new Date().getFullYear()} Amanda Garden Hotel. All Rights Reserved.
          </p>
          <p className="text-gray-600 text-xs">
            Designed with <span className="text-red-400">♥</span> for comfort and luxury.
          </p>
        </div>
      </div>

      {/* Scroll to top */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-24 right-6 z-50 w-10 h-10 rounded-full bg-gold/90 text-dark flex items-center justify-center shadow-lg hover:bg-gold transition-colors"
      >
        <ArrowUp size={18} />
      </button>
    </footer>
  );
}
