import { Award, Users, Clock, Shield } from 'lucide-react';

interface AboutProps {
  aboutText: string;
  aboutText2: string;
}

export default function AboutSection({ aboutText, aboutText2 }: AboutProps) {
  return (
    <section id="about" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">Discover Us</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            About <span className="gold-text">Our Hotel</span>
          </h2>
          <div className="section-divider-lg mb-6" />
          <div className="flex justify-center gap-1 mb-2">
            <span className="text-gold text-lg">✦</span>
            <span className="text-gold/40 text-lg">✦</span>
            <span className="text-gold text-lg">✦</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          {/* Left - Text */}
          <div className="space-y-6">
            <p className="text-gray-300 leading-relaxed text-base">{aboutText}</p>
            <p className="text-gray-400 leading-relaxed text-sm">{aboutText2}</p>
            <div className="flex items-center gap-4 pt-4">
              <div className="w-16 h-[2px] bg-gradient-to-r from-gold to-transparent" />
              <p className="font-cormorant italic text-gold text-lg">Your comfort, our commitment</p>
            </div>
          </div>

          {/* Right - Feature cards */}
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Award, title: 'Award Winning', desc: 'Recognized for excellence in hospitality' },
              { icon: Users, title: 'Expert Team', desc: 'Trained professionals at your service' },
              { icon: Clock, title: '24/7 Service', desc: 'Round the clock assistance' },
              { icon: Shield, title: 'Safe & Secure', desc: 'Your safety is our priority' },
            ].map((item, i) => (
              <div key={i} className="luxury-card bg-dark-card border border-dark-border rounded-xl p-6 text-center group hover:border-gold/30">
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors">
                  <item.icon size={24} className="text-gold" />
                </div>
                <h4 className="font-playfair font-semibold text-white text-sm mb-2">{item.title}</h4>
                <p className="text-gray-500 text-xs leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
