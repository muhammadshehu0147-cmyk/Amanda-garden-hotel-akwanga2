import { ChevronRight, Star } from 'lucide-react';

interface HeroProps {
  hotelName: string;
  tagline: string;
  heroSubtext: string;
}

export default function HeroSection({ hotelName, tagline, heroSubtext }: HeroProps) {
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0a] via-[#1a0f00] to-[#0a0a0a]" />
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c9a84c' fill-opacity='0.08'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }} />
        {/* Decorative circles */}
        <div className="absolute top-20 right-10 w-96 h-96 rounded-full bg-gold/5 blur-3xl" />
        <div className="absolute bottom-20 left-10 w-72 h-72 rounded-full bg-gold/3 blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <div className="animate-fade-in-up opacity-0" style={{ animationDelay: '0.2s', animationFillMode: 'forwards' }}>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-12 h-[1px] bg-gold" />
                <span className="text-gold text-xs tracking-[4px] uppercase font-montserrat font-medium">Welcome to</span>
              </div>
              <h1 className="font-playfair text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-white">{hotelName.split(' ').slice(0, 1)}</span>
                <br />
                <span className="gold-text">{hotelName.split(' ').slice(1).join(' ')}</span>
              </h1>
            </div>

            <div className="animate-fade-in-up opacity-0" style={{ animationDelay: '0.4s', animationFillMode: 'forwards' }}>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={14} className="fill-gold text-gold" />
                  ))}
                </div>
                <span className="text-gold/80 text-sm font-cormorant italic tracking-wider">{tagline}</span>
              </div>
              <p className="text-gray-400 text-base leading-relaxed max-w-lg font-light">
                {heroSubtext}
              </p>
            </div>

            <div className="flex flex-wrap gap-4 animate-fade-in-up opacity-0" style={{ animationDelay: '0.6s', animationFillMode: 'forwards' }}>
              <button onClick={() => scrollTo('booking')} className="btn-gold rounded-lg flex items-center gap-2 text-sm group">
                Book Your Stay
                <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button onClick={() => scrollTo('rooms')} className="btn-gold-outline rounded-lg text-sm">
                View Rooms
              </button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 pt-4 animate-fade-in-up opacity-0" style={{ animationDelay: '0.8s', animationFillMode: 'forwards' }}>
              {[
                { num: '50+', label: 'Luxury Rooms' },
                { num: '24/7', label: 'Service' },
                { num: '1000+', label: 'Happy Guests' },
              ].map((stat) => (
                <div key={stat.label}>
                  <p className="font-playfair text-2xl font-bold gold-text">{stat.num}</p>
                  <p className="text-gray-500 text-xs tracking-wider uppercase">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right side - decorative card */}
          <div className="hidden lg:block animate-fade-in-up opacity-0" style={{ animationDelay: '0.5s', animationFillMode: 'forwards' }}>
            <div className="relative">
              {/* Main image placeholder */}
              <div className="rounded-2xl overflow-hidden border border-gold/20 shadow-2xl shadow-gold/5">
                <div className="aspect-[4/3] bg-gradient-to-br from-[#1a1510] via-[#2a1f14] to-[#1a1510] flex items-center justify-center relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center space-y-4">
                      <div className="w-20 h-20 mx-auto rounded-full bg-gold/10 flex items-center justify-center border border-gold/30 animate-float">
                        <span className="font-playfair text-3xl gold-text font-bold">AG</span>
                      </div>
                      <p className="font-cormorant text-xl text-gold/60 italic">Experience Luxury</p>
                    </div>
                  </div>
                  {/* Decorative grid lines */}
                  <div className="absolute inset-0 opacity-10" style={{
                    backgroundImage: 'linear-gradient(rgba(201,168,76,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(201,168,76,0.2) 1px, transparent 1px)',
                    backgroundSize: '40px 40px'
                  }} />
                </div>
              </div>

              {/* Floating badge */}
              <div className="absolute -bottom-6 -left-6 bg-dark-card border border-gold/20 rounded-xl p-4 shadow-xl animate-float" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center">
                    <Star className="fill-gold text-gold" size={18} />
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">Premium</p>
                    <p className="text-gold/60 text-xs">5-Star Service</p>
                  </div>
                </div>
              </div>

              {/* Floating price badge */}
              <div className="absolute -top-4 -right-4 bg-gold rounded-xl px-4 py-3 shadow-xl">
                <p className="text-dark text-xs font-semibold">Starting from</p>
                <p className="text-dark font-playfair font-bold text-lg">₦10,000</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom features bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-dark-card/80 backdrop-blur-sm border-t border-gold/10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: '🏨', title: 'Luxury Rooms', desc: 'Beautifully designed rooms' },
              { icon: '✨', title: 'Premium Amenities', desc: 'World-class facilities' },
              { icon: '🤝', title: 'Excellent Service', desc: 'Dedicated staff always' },
              { icon: '📍', title: 'Best Location', desc: 'Heart of Akwanga' },
            ].map((item) => (
              <div key={item.title} className="flex items-center gap-3">
                <span className="text-2xl">{item.icon}</span>
                <div>
                  <p className="text-xs font-semibold text-gold uppercase tracking-wider">{item.title}</p>
                  <p className="text-[10px] text-gray-500">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
