import { CalendarDays, Users, BedDouble, MessageCircle } from 'lucide-react';
import { useState } from 'react';
import type { RoomType } from '../store';

interface BookingProps {
  rooms: RoomType[];
  whatsapp: string;
  phone: string;
}

export default function BookingSection({ rooms, whatsapp, phone }: BookingProps) {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    roomType: '',
    checkIn: '',
    checkOut: '',
    guests: '1',
    specialRequests: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const room = rooms.find(r => r.id === form.roomType);
    const message = `🏨 *BOOKING REQUEST - Amanda Garden Hotel*%0A%0A👤 Name: ${form.name}%0A📞 Phone: ${form.phone}%0A📧 Email: ${form.email}%0A🛏️ Room: ${room?.name || 'Not specified'}%0A📅 Check-in: ${form.checkIn}%0A📅 Check-out: ${form.checkOut}%0A👥 Guests: ${form.guests}%0A📝 Notes: ${form.specialRequests || 'None'}`;
    window.open(`https://wa.me/${whatsapp}?text=${message}`, '_blank');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="booking" className="py-20 md:py-28 bg-dark-surface/50 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">Reserve Your Stay</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            Book <span className="gold-text">Now</span>
          </h2>
          <div className="section-divider-lg mb-4" />
          <p className="text-gray-400 text-sm">
            Fill out the form below and we'll confirm your booking via WhatsApp or phone call
          </p>
        </div>

        <div className="bg-dark-card border border-dark-border rounded-2xl p-6 md:p-10">
          {submitted ? (
            <div className="text-center py-12 space-y-4 animate-scale-in">
              <div className="text-6xl mb-4">✨</div>
              <h3 className="font-playfair text-2xl font-bold gold-text">Booking Request Sent!</h3>
              <p className="text-gray-400 text-sm max-w-md mx-auto">
                Your booking request has been sent via WhatsApp. Our team will confirm your reservation shortly.
              </p>
              <p className="text-gray-500 text-xs">
                You can also call us directly at <a href={`tel:${phone.replace(/\s/g, '')}`} className="text-gold underline">{phone}</a>
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="John Doe"
                    className="w-full input-luxury rounded-lg"
                  />
                </div>
                <div>
                  <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="080XXXXXXXX"
                    className="w-full input-luxury rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Email</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="your@email.com"
                  className="w-full input-luxury rounded-lg"
                />
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 flex items-center gap-1">
                    <BedDouble size={12} /> Room Type *
                  </label>
                  <select
                    required
                    value={form.roomType}
                    onChange={(e) => setForm({ ...form, roomType: e.target.value })}
                    className="w-full input-luxury rounded-lg"
                  >
                    <option value="">Select Room</option>
                    {rooms.map(r => (
                      <option key={r.id} value={r.id}>{r.name} — {r.price}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 flex items-center gap-1">
                    <CalendarDays size={12} /> Check-in *
                  </label>
                  <input
                    type="date"
                    required
                    value={form.checkIn}
                    onChange={(e) => setForm({ ...form, checkIn: e.target.value })}
                    className="w-full input-luxury rounded-lg"
                  />
                </div>
                <div>
                  <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 flex items-center gap-1">
                    <CalendarDays size={12} /> Check-out *
                  </label>
                  <input
                    type="date"
                    required
                    value={form.checkOut}
                    onChange={(e) => setForm({ ...form, checkOut: e.target.value })}
                    className="w-full input-luxury rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 flex items-center gap-1">
                  <Users size={12} /> Number of Guests
                </label>
                <select
                  value={form.guests}
                  onChange={(e) => setForm({ ...form, guests: e.target.value })}
                  className="w-full input-luxury rounded-lg"
                >
                  {[1, 2, 3, 4, 5, 6].map(n => (
                    <option key={n} value={n}>{n} Guest{n > 1 ? 's' : ''}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-gold text-xs uppercase tracking-wider font-medium mb-2 block">Special Requests</label>
                <textarea
                  value={form.specialRequests}
                  onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
                  placeholder="Any special requirements or notes..."
                  rows={3}
                  className="w-full input-luxury rounded-lg resize-none"
                />
              </div>

              <button type="submit" className="btn-gold rounded-lg w-full flex items-center justify-center gap-2 py-4 text-sm">
                <MessageCircle size={16} />
                Send Booking via WhatsApp
              </button>

              <p className="text-center text-gray-500 text-xs">
                Or call directly: <a href={`tel:${phone.replace(/\s/g, '')}`} className="text-gold hover:underline">{phone}</a>
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
