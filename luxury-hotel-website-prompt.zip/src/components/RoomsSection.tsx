import { Wifi, Wind, Tv, Bath, ChevronRight } from 'lucide-react';
import type { RoomType } from '../store';

interface RoomsProps {
  rooms: RoomType[];
}

const roomGradients = [
  'from-[#1a1520] via-[#201828] to-[#1a1520]',
  'from-[#151a20] via-[#182028] to-[#151a20]',
  'from-[#1a1815] via-[#282018] to-[#1a1815]',
  'from-[#15201a] via-[#182820] to-[#15201a]',
  'from-[#201a15] via-[#281e18] to-[#201a15]',
  'from-[#1a1a20] via-[#202028] to-[#1a1a20]',
];

const roomIcons = ['🛏️', '🏠', '👔', '💎', '🏛️', '🌿'];

export default function RoomsSection({ rooms }: RoomsProps) {
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="rooms" className="py-20 md:py-28 bg-dark-surface/50 relative">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">Accommodation</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            Our <span className="gold-text">Rooms</span>
          </h2>
          <div className="section-divider-lg mb-4" />
          <p className="text-gray-400 text-sm max-w-xl mx-auto">
            Choose from our range of beautifully appointed rooms designed for your comfort and relaxation
          </p>
        </div>

        {/* Room cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {rooms.map((room, i) => (
            <div key={room.id} className="luxury-card group rounded-2xl overflow-hidden border border-dark-border hover:border-gold/30 bg-dark-card">
              {/* Image area */}
              <div className="relative aspect-[16/10] overflow-hidden">
                {room.images.length > 0 ? (
                  <img src={room.images[0]} alt={room.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                ) : (
                  <div className={`w-full h-full bg-gradient-to-br ${roomGradients[i % roomGradients.length]} flex items-center justify-center`}>
                    <div className="text-center">
                      <span className="text-4xl mb-2 block">{roomIcons[i % roomIcons.length]}</span>
                      <p className="text-gold/40 text-xs font-cormorant italic">Upload image via admin</p>
                    </div>
                  </div>
                )}
                {/* Price badge */}
                <div className="absolute top-3 right-3 bg-gold/90 backdrop-blur-sm rounded-lg px-3 py-1.5">
                  <p className="text-dark font-bold text-sm">{room.price}</p>
                  {room.price !== 'Negotiable' && <p className="text-dark/70 text-[10px]">per night</p>}
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h3 className="font-playfair text-lg font-bold text-white mb-2 group-hover:text-gold transition-colors">{room.name}</h3>
                <p className="text-gray-400 text-xs leading-relaxed mb-4 line-clamp-2">{room.description}</p>
                
                {/* Amenities */}
                <div className="flex gap-3 mb-4">
                  {[Wifi, Wind, Tv, Bath].map((Icon, idx) => (
                    <div key={idx} className="w-8 h-8 rounded-lg bg-dark-surface flex items-center justify-center">
                      <Icon size={14} className="text-gold/60" />
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => scrollTo('booking')}
                  className="w-full btn-gold-outline rounded-lg text-xs py-2.5 flex items-center justify-center gap-2 group/btn"
                >
                  Book Now
                  <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
