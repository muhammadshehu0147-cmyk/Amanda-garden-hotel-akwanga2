import { useState, useEffect } from 'react';
import { Search, Phone, MapPin, Menu, X } from 'lucide-react';

interface NavbarProps {
  onAdminTrigger: () => void;
  phone: string;
  address: string;
}

export default function Navbar({ onAdminTrigger, phone, address }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchVal, setSearchVal] = useState('');

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (val: string) => {
    setSearchVal(val);
    if (val.trim().toLowerCase() === '#admin') {
      onAdminTrigger();
      setSearchVal('');
    }
  };

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileOpen(false);
  };

  const navLinks = [
    { label: 'Home', id: 'hero' },
    { label: 'About', id: 'about' },
    { label: 'Rooms', id: 'rooms' },
    { label: 'Facilities', id: 'facilities' },
    { label: 'Gallery', id: 'gallery' },
    { label: 'Contact', id: 'contact' },
  ];

  return (
    <>
      {/* Top bar */}
      <div className="bg-dark-surface text-xs text-gray-400 py-2 px-4 hidden md:flex justify-between items-center border-b border-dark-border">
        <div className="flex items-center gap-2">
          <MapPin size={12} className="text-gold" />
          <span>{address}</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Phone size={12} className="text-gold" />
            <span>{phone}</span>
          </div>
        </div>
      </div>

      {/* Main navbar */}
      <nav className={`fixed top-0 md:top-[33px] left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'navbar-scrolled !top-0' : 'bg-dark/80 backdrop-blur-sm'}`}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollTo('hero')}>
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center text-dark font-bold font-playfair text-lg">
              AG
            </div>
            <div className="hidden sm:block">
              <h1 className="font-playfair text-lg font-bold gold-text leading-tight">Amanda Garden</h1>
              <p className="text-[10px] tracking-[3px] text-gold/60 uppercase">Hotel</p>
            </div>
          </div>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map(link => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-sm font-medium text-gray-300 hover:text-gold transition-colors duration-300 tracking-wide uppercase"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Search + Book */}
          <div className="flex items-center gap-3">
            <div className="relative hidden sm:block">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                value={searchVal}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Search..."
                className="bg-dark-surface border border-dark-border rounded-full pl-9 pr-4 py-2 text-xs text-gray-300 w-36 focus:w-48 focus:border-gold/50 outline-none transition-all duration-300"
              />
            </div>
            <button
              onClick={() => scrollTo('booking')}
              className="btn-gold rounded-full text-xs px-5 py-2.5 hidden sm:block"
            >
              Book Now
            </button>
            <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden text-gold">
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden bg-dark-surface/98 backdrop-blur-xl border-t border-dark-border animate-fade-in">
            <div className="px-4 py-4 space-y-1">
              {/* Mobile search */}
              <div className="relative mb-4 sm:hidden">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  value={searchVal}
                  onChange={(e) => handleSearch(e.target.value)}
                  placeholder="Search..."
                  className="bg-dark border border-dark-border rounded-full pl-9 pr-4 py-2.5 text-sm text-gray-300 w-full focus:border-gold/50 outline-none"
                />
              </div>
              {navLinks.map(link => (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className="block w-full text-left py-3 px-4 text-sm text-gray-300 hover:text-gold hover:bg-dark/50 rounded-lg transition-all uppercase tracking-wider"
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => scrollTo('booking')}
                className="btn-gold rounded-lg w-full mt-3 text-sm"
              >
                Book Now
              </button>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
