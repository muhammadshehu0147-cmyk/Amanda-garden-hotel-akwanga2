import { Camera, X } from 'lucide-react';
import { useState } from 'react';

interface GalleryProps {
  images: string[];
}

export default function GallerySection({ images }: GalleryProps) {
  const [lightbox, setLightbox] = useState<string | null>(null);

  const placeholderGradients = [
    'from-[#1a1510] to-[#2a1f14]',
    'from-[#0a3d62] to-[#1e5f74]',
    'from-[#2d1b00] to-[#5a3a1a]',
    'from-[#1a0a2e] to-[#2d1854]',
    'from-[#1a1a1a] to-[#3d3428]',
    'from-[#0d1b2a] to-[#2d4050]',
  ];

  const placeholderEmojis = ['🏨', '🌅', '🍽️', '🏊', '🌴', '🎉', '🛏️', '✨'];

  return (
    <section id="gallery" className="py-20 md:py-28 bg-dark-surface/50 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <span className="text-gold text-xs tracking-[4px] uppercase font-medium">Visual Tour</span>
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mt-3 mb-4">
            <span className="gold-text">Gallery</span>
          </h2>
          <div className="section-divider-lg mb-4" />
          <p className="text-gray-400 text-sm max-w-xl mx-auto">
            Explore our beautiful hotel through our gallery. More images coming soon!
          </p>
        </div>

        {images.length > 0 ? (
          <div className="masonry-grid">
            {images.map((img, i) => (
              <div key={i} className="cursor-pointer group" onClick={() => setLightbox(img)}>
                <div className="rounded-xl overflow-hidden border border-dark-border group-hover:border-gold/30 transition-all">
                  <img
                    src={img}
                    alt={`Gallery ${i + 1}`}
                    className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="luxury-card rounded-xl overflow-hidden border border-dark-border hover:border-gold/20">
                <div
                  className={`aspect-square bg-gradient-to-br ${placeholderGradients[i % placeholderGradients.length]} flex items-center justify-center`}
                  style={{ aspectRatio: i % 3 === 0 ? '1/1.3' : i % 3 === 1 ? '1/0.8' : '1/1' }}
                >
                  <div className="text-center space-y-2">
                    <span className="text-3xl">{placeholderEmojis[i % placeholderEmojis.length]}</span>
                    <div className="flex items-center gap-1 justify-center text-gray-600">
                      <Camera size={10} />
                      <p className="text-[10px]">Coming soon</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {images.length > 0 && (
          <div className="text-center mt-8">
            <p className="text-gray-500 text-sm">{images.length} photos in gallery</p>
          </div>
        )}
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 z-[100] admin-overlay flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
          <button className="absolute top-4 right-4 text-white hover:text-gold transition-colors" onClick={() => setLightbox(null)}>
            <X size={32} />
          </button>
          <img src={lightbox} alt="Gallery" className="max-w-full max-h-[90vh] object-contain rounded-lg" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </section>
  );
}
